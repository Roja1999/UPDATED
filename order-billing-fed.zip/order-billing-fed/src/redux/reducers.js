import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    orders: [],
    clerk: "",
    error: null,
    editMode: null,
    totalRegular: 0,
    totalDiscounted: 0,
    toast: {
        message: '',
        type: ''
    },
};

const orderSlice = createSlice({
    name: 'orders',
    initialState,
    reducers: {
        showToast(state, action) {
            state.toast = action.payload;
        },
        setClerk(state, action) {
            state.clerk = action.payload;
        },
        setOrders(state, action) {
            state.orders = action.payload;
        },
        setTotalRegularBill(state, action) {
            state.totalRegular = Number(action.payload);
        },
        setTotalDiscountedBill(state, action) {
            state.totalDiscounted = Number(action.payload);
        },
        setEditMode(state, action) {
            state.editMode = action.payload;
        },
        clearEditMode(state) {
            state.editMode = null;
        },
        setError(state, action) {
            state.error = action.payload;
        },
    },
});

export const {
    showToast,
    setClerk,
    setOrders,
    addOrder,
    deleteOrder,
    updateOrder,
    setTotalRegularBill,
    setTotalDiscountedBill,
    setEditMode,
    clearEditMode,
    setError,
} = orderSlice.actions;

export default orderSlice.reducer;