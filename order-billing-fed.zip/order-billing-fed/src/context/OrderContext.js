import React, { createContext, useReducer, useEffect, useCallback } from 'react';
import orderReducer, {
    setClerk,
    setOrders,
    setTotalRegularBill,
    setTotalDiscountedBill,
    setEditMode,
    clearEditMode,
    setError,
    showToast,
} from '../redux/reducers';
import { useLocation } from 'react-router-dom';

export const OrderContext = createContext();

const OrderProvider = ({ children }) => {
    const [state, dispatch] = useReducer(orderReducer, {
        orders: [],
        totalRegular: 0,
        totalDiscounted: 0,
        toast: {
            message: '',
            type: ''
        },
        error: null,
        editMode: null,
    });

    const location = useLocation();

    // Memoize fetchOrders using useCallback
    const fetchOrders = useCallback(async () => {
        try {
            const response = await fetch('http://localhost:9090/order-billing-ws/getOrders');
            const orders = await response.json();
            dispatch(setOrders(orders));
            dispatch(showToast({ message: 'Orders successfully fetched', type: 'green' }));
        } catch (error) {
            dispatch(setError('Unable to fetch orders. Something went wrong'));
            dispatch(showToast({ message: 'Unable to fetch orders. Something went wrong', type: 'red' }));
        }
    }, [dispatch]);

    const getTotalRegularBill = useCallback(async (init = false) => {
        try {
            const response = await fetch('http://localhost:9090/order-billing-ws/getTotalRegularBill');
            const result = await response.json();
            dispatch(setOrders(result.orderList));
            dispatch(setClerk(result.clerk.name));
            dispatch(setTotalRegularBill(parseFloat(result.totalBill)));
        } catch (error) {
            console.log(error);
            throw new Error("Cannot load details. Something went wrong");
        }
    }, [dispatch]);

    const getTotalDiscountedBill = useCallback(async (init = false) => {
        try {
            const response = await fetch('http://localhost:9090/order-billing-ws/getTotalDiscountedBill');
            const result = await response.json();
            dispatch(setOrders(result.orderList));
            dispatch(setClerk(result.clerk.name));
            dispatch(setTotalDiscountedBill(parseFloat(result.totalBill)));
        } catch (error) {
            console.log(error);
            throw new Error("Cannot load details. Something went wrong");
        }
    }, [dispatch]);

    useEffect(() => {
        if (location.pathname === '/') {
            (async () => {
                try {
                    // await fetchClerk(true);
                    await getTotalRegularBill();
                    await getTotalDiscountedBill();
                    // await fetchOrders();
                } catch (error) {
                    dispatch(showToast({ message: error.message, type: 'red' }));
                    dispatch(setError(error.message));
                }
            })();
        }
    }, [location, dispatch, fetchOrders, getTotalRegularBill, getTotalDiscountedBill, state.error]);

    const addOrderToState = async (order) => {
        try {
            await fetch('http://localhost:9090/order-billing-ws/addOrder', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    orderName: order.orderName,
                    price: parseFloat(order.price),
                    isDiscounted: order.promo
                }),
            });
            await getTotalRegularBill();
            await getTotalDiscountedBill();
            dispatch(showToast({ message: 'Order successfully added', type: 'green' }));
        } catch (error) {
            dispatch(setError('Unable to add order'));
            dispatch(showToast({ message: 'Unable to add order. Something went wrong', type: 'red' }));
        }
    };

    const deleteOrderFromState = async (orderId) => {
        try {
            await fetch(`http://localhost:9090/order-billing-ws/deleteOrder/${orderId}`, {
                method: 'DELETE',
            });
            await getTotalRegularBill();
            await getTotalDiscountedBill();
            dispatch(showToast({ message: 'Order successfully deleted', type: 'green' }));
        } catch (error) {
            dispatch(setError('Unable to delete order'));
            dispatch(showToast({ message: 'Unable to delete order. Something went wrong', type: 'red' }));
        }
    };

    const updateOrderInState = async (order) => {
        try {
            await fetch(`http://localhost:9090/order-billing-ws/updateOrder/${order.id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(order),
            });
            await getTotalRegularBill();
            await getTotalDiscountedBill();
            dispatch(showToast({ message: 'Order successfully updated', type: 'green' }));
        } catch (error) {
            dispatch(setError('Unable to update order'));
            dispatch(showToast({ message: 'Unable to update order. Something went wrong', type: 'red' }));
        }
    };

    const showToastToState = (toast) => {
        dispatch(showToast(toast));
    };

    return (
        <OrderContext.Provider
            value={{
                orders: state.orders,
                clerk: state.clerk,
                toast: state.toast,
                totalRegular: state.totalRegular,
                totalDiscounted: state.totalDiscounted,
                error: state.error,
                showToast: showToastToState,
                addOrder: addOrderToState,
                deleteOrder: deleteOrderFromState,
                updateOrder: updateOrderInState,
                setEditMode: (order) => dispatch(setEditMode(order)),
                clearEditMode: () => dispatch(clearEditMode()),
                editMode: state.editMode,
            }}
        >
            {children}
        </OrderContext.Provider>
    );
};

export default OrderProvider;