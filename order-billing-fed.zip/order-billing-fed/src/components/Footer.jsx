import React from 'react';

const Footer = () => (
    <footer className="bg-gray-800 text-white py-4 text-center">
        &copy; All rights reserved {new Date().getFullYear()} @KoopiTearia
    </footer>
);

export default Footer;