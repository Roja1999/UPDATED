import React from 'react';

const SideMenu = () => (
    <section className="md:w-1/3">
        {/* Left Sidebar with Menu Image */}
        <img src="/images/menu.jpg" alt="Drinks Menu" className="object-cover" />
    </section>
);

export default SideMenu;