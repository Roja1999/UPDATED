import React, { useEffect, useState, useContext } from 'react';
import { OrderContext } from '../context/OrderContext';

const ToastContainer = () => {
    const { toast, showToast } = useContext(OrderContext);
    const [show, setShow] = useState("hidden");

    useEffect(() => {
        if (toast && toast.type !== "") {
            setShow("");
            const timer = setTimeout(() => {
                showToast({ message: '', type: '' });
            }, 3000); // Auto-hide after 3 seconds
            return () => clearTimeout(timer);
        } else setShow("hidden");
    }, [toast, showToast]);
    console.log(toast);
    let color = "";
    if (toast.type === "green") color = "bg-green-500";
    else if (toast.type === "red") color = "bg-red-500";
    return (
        toast && (
            <div key={`${toast.message}-${toast.type}`} className={`${color} text-white p-2 w-full ${show}`}>
                <div className="flex items-center justify-center">
                    <span>{toast.message}</span>
                    <button
                        onClick={() => showToast({ message: '', type: '' })}
                        className="mx-2 py-1 px-2 text-sm font-medium text-center text-black bg-white rounded-lg hover:bg-white focus:ring-4 focus:outline-none focus:ring-white dark:bg-white dark:hover:bg-white dark:focus:ring-white"
                    >&#x2715;</button>
                </div>
            </div>
        )
    );
};

export default ToastContainer;