import React, { useEffect, useContext, useRef } from 'react';
import { Link } from 'react-router-dom';
import { OrderContext } from '../context/OrderContext';

const NotFound = () => {
    const { showToast } = useContext(OrderContext);
    const showToastRef = useRef(showToast);
    useEffect(() => {
        showToastRef.current({ message: "Unsupported web page URL.", type: "red" });
    }, []);

    return (
        <main className="flex-1 flex md:w-3/4 mx-auto">
            <Link className='underline text-blue-400 p-4' to="/">Back to Order Page</Link>
        </main>
    );
}

export default NotFound;