import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import store from './redux/store';
import OrderProvider from './context/OrderContext';
import Header from './components/Header';
import DiscountMessage from './components/DiscountMessage';
import OrderForm from './components/OrderForm';
import OrderList from './components/OrderList';
import SideMenu from './components/SideMenu';
import Footer from './components/Footer';
import ToastContainer from './components/ToastContainer';
import withErrorBoundary from './hoc/withErrorBoundary';
import './styles/App.css';
import NotFound from './components/NotFound';

const App = () => (
  <Provider store={store}>
    <div className="flex flex-col min-h-screen bg-gray-100">
      <Header />
      <DiscountMessage />
      <Router>
        <OrderProvider>
          <ToastContainer />
          <Routes>
            <Route path="/" element={<main className="flex-1 flex md:w-3/4 mx-auto">
              <SideMenu />
              <div className="flex-1 p-4">
                <OrderForm />
                <OrderList />
              </div>
            </main>} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </OrderProvider>
      </Router>
      <Footer />
    </div>
  </Provider>
);

export default withErrorBoundary(App);