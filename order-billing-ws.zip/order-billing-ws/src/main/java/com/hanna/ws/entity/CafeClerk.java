package com.hanna.ws.entity;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CafeClerk {

    private final String name;

    // Injecting the value from application.properties using @Value
    public CafeClerk(@Value("${cafe.clerk.name}") String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
