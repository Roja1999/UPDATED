package com.hanna.ws.impl;

import com.hanna.ws.controller.OrderAndBillingController;
import com.hanna.ws.entity.Order;
import com.hanna.ws.repository.OrderRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
class OrderBillingApplicationTests {

    @InjectMocks
    private OrderAndBillingController orderAndBillingController;

    @Mock
    private OrderRepository orderRepo;

    private Order order1;
    private Order order2;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Initialize the order data
        order1 = new Order();
        order1.setId(1L);
        order1.setOrderName("Latte");
        order1.setPrice(4.5);
        order1.setDiscounted(true);

        order2 = new Order();
        order2.setId(2L);
        order2.setOrderName("Tea");
        order2.setPrice(5.5);
        order2.setDiscounted(false);
    }

    @Test
    void getOrderListTest() {
        // Mock the database response with pre-existing orders
        when(orderRepo.findAll()).thenReturn(Arrays.asList(order1, order2));

        // Call the controller's method to fetch the list
        List<Order> orders = orderAndBillingController.getOrderList();

        // Assertions to verify that the orders match the expected results
        assertEquals(2, orders.size());

        assertEquals(1L, orders.get(0).getId());
        assertEquals("Latte", orders.get(0).getOrderName());
        assertEquals(4.5, orders.get(0).getPrice());
        assertEquals(5.0, orders.get(0).getDiscountedPercentage()); // Assuming 5% discount
        assertTrue(orders.get(0).isDiscounted());

        assertEquals(2L, orders.get(1).getId());
        assertEquals("Tea", orders.get(1).getOrderName());
        assertEquals(5.5, orders.get(1).getPrice());
        assertEquals(5.0, orders.get(1).getDiscountedPercentage()); // Assuming 5% discount
        assertFalse(orders.get(1).isDiscounted());
    }

    @Test
    void addOrderTest() {
        // Create a new order to be inserted
        Order newOrder = new Order();
        newOrder.setOrderName("Café Latte");
        newOrder.setPrice(3.5);
        newOrder.setDiscounted(true);

        // Call the addOrder method
        orderAndBillingController.addOrder(newOrder);

        // Verify that the save method is called once for the new order
        verify(orderRepo, times(1)).save(newOrder);
    }

    @Test
    void updateOrderTest() {
        // Create an order that exists in the database
        Order existingOrder = new Order();
        existingOrder.setId(1L);
        existingOrder.setOrderName("Café Latte");
        existingOrder.setPrice(3.5);
        existingOrder.setDiscounted(true);

        // Mock finding the existing order by ID
        when(orderRepo.findById(1L)).thenReturn(Optional.of(existingOrder));

        // Create the updated order
        Order updatedOrder = new Order();
        updatedOrder.setId(1L);
        updatedOrder.setOrderName("Café Mocha");
        updatedOrder.setPrice(3.5);
        updatedOrder.setDiscounted(false);

        // Call the updateOrder method
        orderAndBillingController.updateOrder(1L, updatedOrder);

        // Verify that the save method is called once with the updated order
        verify(orderRepo, times(1)).save(argThat(order ->
                order.getId().equals(updatedOrder.getId()) &&
                        order.getOrderName().equals(updatedOrder.getOrderName()) &&
                        order.getPrice() == updatedOrder.getPrice() &&
                        order.isDiscounted() == updatedOrder.isDiscounted()
        ));
    }

    @Test
    void deleteOrderTest() {
        // Create an order that will be deleted
        Order orderToDelete = new Order();
        orderToDelete.setId(1L);
        orderToDelete.setOrderName("Café Mocha");
        orderToDelete.setPrice(3.5);
        orderToDelete.setDiscounted(false);

        // Mock finding the order by ID
        when(orderRepo.findById(1L)).thenReturn(Optional.of(orderToDelete));

        // Call the deleteOrder method
        orderAndBillingController.deleteOrder(1L);

        // Verify that the deleteById method is called once with the correct ID
        verify(orderRepo, times(1)).deleteById(1L);
    }
}
